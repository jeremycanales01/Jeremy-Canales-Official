/**
 * External dependencies
 */
import '@storybook/addon-viewport/register';
